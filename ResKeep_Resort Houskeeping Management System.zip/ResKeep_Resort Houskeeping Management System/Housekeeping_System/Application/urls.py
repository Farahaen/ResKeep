from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.welcomepage, name='welcomepage'),


    path('housekeeper/', views.housekeeper, name='housekeeper'),
    path('housekeeper_login/', views.housekeeper_login, name='housekeeper_login'),  
    path('housekeeper_homepage/', views.housekeeper_homepage, name='housekeeper_homepage'),
    path('availability_view/', views.availability_view, name='availability_view'),  
    path('supplies_inventory/', views.supplies_inventory, name='supplies_inventory'),
    path('supplies/update/<int:supply_id>/', views.update_supply, name='update_supply'),
    path('supplies/request/<int:supply_id>/', views.request_supply, name='request_supply'),
    path('add-lost-item/', views.add_lost_item, name='add_lost_item'),
    path('housekeeper/maintenance/', views.housekeeper_maintenance, name='housekeepermaintenance'),
    path('housekeeper/tasks/', views.housekeeper_tasks, name='housekeeper_tasks'),
    path('housekeeper/tasks/update_taskstatus/<int:task_id>/', views.update_task_status, name='update_task_tatus'),
    path('housekeeper/room_status/', views.housekeeper_room_status, name='housekeeper_room_status'),
    path('housekeeper/room_status/update_room_status/<str:room_no>/', views.update_room_status, name='update_room_status'),


    path('supervisor/', views.supervisor, name='supervisor'),
    path('supervisor_login/', views.supervisor_login, name='supervisor_login'),
    path('supervisor_homepage/', views.supervisor_homepage, name='supervisor_homepage'),
    path('taskpage/', views.taskpage, name='taskpage'),
    path('tasklists/', views.tasklists, name='tasklists'),
    path('task/assign/', views.assign_task, name='assign_task'),
    path('task/edit_task/<int:task_id>/', views.edit_task, name='edit_task'),  # Edit task form
    path('task/edit_taskdata/<int:task_id>/', views.edit_taskdata, name='edit_taskdata'),  # Handle task edit data
    path('task/', views.tasklists, name='tasklists'),  # List all tasks
    path('task/delete/<int:task_id>/', views.delete_task, name='delete_task'),
    path('task/assign/', views.assign_task, name='assign_task'),  # Show the form
    path('task/assign_taskdata/', views.assign_taskdata, name='assign_taskdata'),  # Handle form submission
    path('room_status_view/', views.room_status_view, name='room_status_view'),
    path('approve_status/<str:room_no>/', views.approve_status, name='approve_status'),
    path('lost_items/', views.lost_item_detail_view, name='lost_item_detail_view'),
    path('update_item_status/<int:lost_item_id>/', views.update_item_status, name='update_item_status'),  # Update status
    
    path('manager/', views.manager, name='manager'), 
    path('manager_login/', views.manager_login, name='manager_login'),
    path('manager_homepage/', views.manager_homepage, name='manager_homepage'),
    path('reportspage/', views.reportspage, name='reportspage'),
    path('room_task_report/', views.room_task_report, name='room_task_report'),
    path('maintenance_list_view/', views.maintenance_list_view, name='maintenance_list_view'),
    path('maintenance_report_view/', views.maintenance_report_view, name='maintenance_report_view'),
    path('maintenance/approve_maintenance_view/<int:maintenance_id>/', views.approve_maintenance_view, name='approve_maintenance_view'),
    path('supplies_report_view/', views.supplies_report_view, name='supplies_report_view'),
    path('supply-requests/', views.supply_request_list_view, name='supply_request_list_view'),
    path('approve-supply-request/<int:request_id>/', views.approve_supply_request, name='approve_supply_request'),
    path('supplies_report_view/', views.supplies_report_view, name='supplies_report_view')
]

if settings.DEBUG: 
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

