from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .models import Housekeeper, SupplyInventory, HousekeeperAvailability, SupplyRequest, Room, LostItem, Maintenance, Task, Supervisor, Manager
from django.shortcuts import render, get_object_or_404
from .forms import HousekeeperProfileForm, SupervisorProfileForm, ManagerProfileForm
from django.http import JsonResponse
import json
from django.urls import reverse
from django.utils import timezone
from django.contrib import messages
from django.http import HttpResponse



# Welcome Page
def welcomepage(request):
    return render(request, '1welcomepg.html')
#to open svlogin pg
def supervisor(request):
    return render(request, '3svloginpg.html')
#to open mnglogin pg
def manager(request):
    return render(request, '4mngloginpg.html')
# --HouseKeeper--
# Housekeeper Login
def housekeeper(request):
    return render(request, '2hsloginpg.html')

 #HOUSEKEEPER PART

#hs login
def housekeeper_login(request):
    error = None
    if request.method == 'POST':
        hs_user_id = request.POST['user_id']
        hs_password = request.POST['password']

        # Check if the housekeeper exists
        hs_exists = Housekeeper.objects.filter(user_id=hs_user_id, password=hs_password).exists()

        if hs_exists:
            request.session['user_id'] = hs_user_id  # Store user ID in session
            return redirect('housekeeper_homepage')  # Redirect to homepage after login
        else:
            error = "Invalid User ID or Password."
    
    return render(request, '2hsloginpg.html', {'error': error})

def housekeeper_homepage(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    if request.method == 'POST':
        form = HousekeeperProfileForm(request.POST, request.FILES, instance=housekeeper)
        if form.is_valid():
            form.save()
            return redirect('housekeeperhomepage')  # Redirect to homepage or success page
    else:
        form = HousekeeperProfileForm(instance=housekeeper)

    # Pass the data to the template
    context = {
        'form': form,
        'housekeeper': housekeeper,
    }

    return render(request, 'hshomepage.html', context)  # Render the homepage template with user data


def availability_view(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on session user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    if request.method == 'POST':
        try:
            # Parse the incoming data from the AJAX request
            data = json.loads(request.body)

            # Create a new HousekeeperAvailability record
            availability = data['availability']
            reason = data['availability_reason'] if not availability else ""

            # Create a new availability entry for this housekeeper
            new_availability = HousekeeperAvailability(
                housekeeper=housekeeper,
                availability=availability,
                reason=reason,
                date_assigned=timezone.now()  # Automatically assigns the current date and time
            )
            new_availability.save()

            # Return success as a JSON response
            return JsonResponse({'success': True})
        except Exception as e:
            # If there's an error, return an error message as a JSON response
            return JsonResponse({'success': False, 'error': str(e)})

    # Fetch all availability records for the housekeeper (for display on the page if needed)
    availabilities = housekeeper.availabilities.all().order_by('-date_assigned')  # Sorted by date, most recent first

    # Render the availability form with the housekeeper and their availability history
    return render(request, 'hsavailpage.html', {'housekeeper': housekeeper, 'availabilities': availabilities})


def supplies_inventory(request):
    supplies = SupplyInventory.objects.all()
    return render(request, 'hssuppliespg.html', {'supplies': supplies})

def update_supply(request, supply_id):
    if request.method == 'POST':
        updated_quantity = int(request.POST.get('quantity'))  # matches input name in HTML
        data = get_object_or_404(SupplyInventory, supply_id=supply_id)

        # Update the current_quantity by subtracting the entered quantity
        data.current_quantity = updated_quantity
        data.save()

        return HttpResponseRedirect(reverse('supplies_inventory'))

    # If it's not a POST request, you can render the form (though it's probably handled elsewhere)
    return redirect('supplies_inventory')  # Redirect to avoid errors on GET requests

def request_supply(request, supply_id):
    # Get the housekeeper ID from the session
    hs_user_id = request.session.get('user_id')

    # Redirect to login if not authenticated
    if hs_user_id is None:
        return JsonResponse({'success': False, 'error': 'Not authenticated.'})

    # Fetch the housekeeper object
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    if request.method == "POST":
        try:
            # Parse the incoming data from the AJAX request
            data = json.loads(request.body)
            requested_quantity = data.get('additional_quantity', 0)
            supply = get_object_or_404(SupplyInventory, pk=supply_id)

            # Create a new supply request entry
            supply_request = SupplyRequest(
                supply=supply,
                requested_quantity=requested_quantity,
                requested_by=housekeeper,  # Use the fetched housekeeper object
            )
            supply_request.save()

            # Return success as a JSON response
            return JsonResponse({'success': True, 'message': 'Your request for additional supplies has been submitted successfully!'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method.'})

def add_lost_item(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on session user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    if request.method == 'POST':
        room_no = request.POST.get('room_no')  # Selected room from the dropdown
        item_type = request.POST.get('item_type')
        item_status = request.POST.get('item_status')

        # Fetch the room object based on the selected room number
        room = get_object_or_404(Room, pk=room_no)

        # Create and save a new LostItem object
        lost_item = LostItem(
            room_no=room,
            item_type=item_type,
            item_status=item_status,
            created_by=housekeeper  # Assign the housekeeper who logged the lost item
        )
        lost_item.save()

        # Display a success message
        messages.success(request, 'Lost item has been successfully added!')

        # Redirect to a page where the user can see the lost items or the form again
        return redirect('add_lost_item')

    # Fetch all rooms to populate the dropdown
    rooms = Room.objects.all()

    return render(request, 'hslostpg.html', {'rooms': rooms, 'housekeeper': housekeeper})
def housekeeper_maintenance(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on session user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    if request.method == 'POST':
        # Fetch form data
        room_no_id = request.POST.get('room_no')
        maintenance_type = request.POST.get('maintenance_type')
        maintenance_description = request.POST.get('maintenance_description')
        maintenance_status = request.POST.get('maintenance_status')

        # Get the room object using the room number ID
        room = get_object_or_404(Room, pk=room_no_id)

        # Create and save a new maintenance request
        maintenance_request = Maintenance(
            room_no=room,
            maintenance_type=maintenance_type,
            maintenance_description=maintenance_description,
            maintenance_status=maintenance_status,
            created_at=timezone.now(),  # Automatically set the maintenance date
            created_by=housekeeper  # Assign the housekeeper who submitted the maintenance request
        )
        maintenance_request.save()

        # Add a success message
        messages.success(request, 'Maintenance request submitted successfully!')

        # Redirect to the maintenance form again or another page
        return redirect('housekeepermaintenance')

    # Fetch all rooms to populate the room dropdown
    rooms = Room.objects.all()

    return render(request, 'hsmaintenancepg.html', {'rooms': rooms, 'housekeeper': housekeeper})

def housekeeper_tasks(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on the session user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    # Fetch only the tasks assigned to the currently logged-in housekeeper
    tasks = Task.objects.filter(assigned_to=housekeeper)

    return render(request, 'hsschedulepg.html', {'tasks': tasks})

def update_task_status(request, task_id):
    if request.method == 'POST':
        task = get_object_or_404(Task, pk=task_id)

        # Ensure the task belongs to the logged-in housekeeper
        hs_user_id = request.session.get('user_id')
        housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

        if task.assigned_to != housekeeper:
            messages.error(request, "You are not authorized to update this task.")
            return redirect('housekeeper_tasks')

        # Update the task status
        new_status = request.POST.get('task_status')
        task.room_task_status = new_status
        task.save()

        messages.success(request, 'Task status has been updated successfully!')
        return redirect('housekeeper_tasks')

    return redirect('housekeeper_tasks')

# View to display tasks assigned to the currently logged-in housekeeper
def housekeeper_room_status(request):
    # Get the housekeeper user ID from session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on the user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    # Fetch rooms cleaned by the current housekeeper
    findassignedtask = Room.objects.filter(cleaned_by=housekeeper)

    return render(request, 'hsroomstatuspg.html', {'findassignedtask': findassignedtask})

# View to update the room status of a specific task
def update_room_status(request, room_no):
    # Get the housekeeper user ID from session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('housekeeper_login')  # Redirect to login if not authenticated

    # Fetch the housekeeper object based on the user_id
    housekeeper = get_object_or_404(Housekeeper, user_id=hs_user_id)

    # Fetch the room based on room_no
    room = get_object_or_404(Room, pk=room_no)

    # Check if the housekeeper is the one who should be cleaning this room
    if room.cleaned_by != housekeeper:
        messages.error(request, 'You do not have permission to update this room status.')
        return redirect('housekeeper_room_status')

    if request.method == 'POST':
        # Get the room status from the form
        room_status = request.POST.get('room_status')

        # Update the room status and clean date on the related Room instance
        room.room_status = room_status
        room.clean_date = timezone.now()
        room.cleaned_by = housekeeper  # Assign the housekeeper

        # Reset room status approval since the status has been updated
        room.room_status_approved = False  # Set to False to require re-approval

        # Save the updated Room instance
        room.save()

        # Add a success message
        messages.success(request, 'Room status updated successfully! Room status approval required.')

        # Redirect to the housekeeper room status page
        return redirect('housekeeper_room_status')

    # In case it's not a POST request, just redirect back to the status page
    return redirect('housekeeper_room_status')


 #SUPERVISOR PART

def supervisor_login(request):
    error = None
    if request.method == 'POST':
        sv_user_id = request.POST['user_id']
        sv_password = request.POST['password']

        # Check if the housekeeper exists
        sv_exists = Supervisor.objects.filter(user_id=sv_user_id, password=sv_password).exists()

        if sv_exists:
            request.session['user_id'] = sv_user_id  # Store user ID in session
            return redirect('supervisor_homepage')  # Redirect to homepage after login
        else:
            error = "Invalid User ID or Password."
    
    return render(request, '3svloginpg.html', {'error': error})

def supervisor_homepage(request):
    # Get the user ID from the session
    hs_user_id = request.session.get('user_id')

    if hs_user_id is None:
        return redirect('supervisor_login')  # Redirect to login if not authenticated

    # Fetch the supervisor object
    supervisor = get_object_or_404(Supervisor, user_id=hs_user_id)

    if request.method == 'POST':
        form = SupervisorProfileForm(request.POST, request.FILES, instance=supervisor)
        if form.is_valid():
            form.save()
            return redirect('supervisor_homepage')  # Redirect to homepage or success page
    else:
        form = SupervisorProfileForm(instance=supervisor)

    # Pass the data to the template
    context = {
        'form': form,
        'supervisor': supervisor,
    }

    return render(request, 'svhomepg.html', context)

def taskpage(request):
    return render(request, 'svtaskpage.html')


                     
def tasklists(request):
    housekeepers = HousekeeperAvailability.objects.all()
    tasks = Task.objects.all()  # Fetch tasks as well
    return render(request, 'svtaskpage.html', {'housekeepers': housekeepers, 'tasks': tasks})
        
def edit_task(request, task_id):
    edittask = get_object_or_404(Task, pk=task_id)
    housekeepers = Housekeeper.objects.all() 
    rooms = Room.objects.all()
    dict = {
        'edittask': edittask,
        'housekeepers': housekeepers,
        'rooms': rooms
    }
    return render(request, 'svedittaskform.html', dict)

# View to handle form submission and update the task
def edit_taskdata(request, task_id):
    room_id = request.POST.get('room_no')  # Get the room ID from the form
    task_description = request.POST.get('task_description')
    assigned_to_id = request.POST.get('assigned_to')  # Get the housekeeper's ID
    due_date = request.POST.get('due_date')
    due_time = request.POST.get('due_time')

    task = get_object_or_404(Task, pk=task_id)
    room = get_object_or_404(Room, pk=room_id)  # Fetch the Room instance
    task.room_no = room  # Assign the Room instance to the ForeignKey

    task.task_description = task_description

    # Assign the housekeeper (foreign key)
    assigned_to = get_object_or_404(Housekeeper, pk=assigned_to_id)
    task.assigned_to = assigned_to

    task.due_date = due_date
    task.due_time = due_time
    task.save()

    return redirect(reverse('tasklists'))  # Redirect after saving
   

# View to delete a task
def delete_task(request, task_id):
    task = get_object_or_404(Task, pk=task_id)
    if request.method == "POST":
        task.delete()
        return redirect('tasklists')

    return render(request, "svdelete.html", {'task': task})
def assign_task(request):
    housekeepers = Housekeeper.objects.all()
    rooms = Room.objects.all()
    context = {
        'housekeepers': housekeepers,
        'rooms': rooms
    }
    return render(request, 'svassigntaskform.html', context)

# View to handle form submission and create a new task
def assign_taskdata(request):
    if request.method == 'POST':
        room_id = request.POST.get('room_no')  # Get the room ID from the form
        task_description = request.POST.get('task_description')
        assigned_to_id = request.POST.get('assigned_to')  # Get the housekeeper's ID
        due_date = request.POST.get('due_date')
        due_time = request.POST.get('due_time')

        # Create a new Task instance
        new_task = Task()

        # Assign the Room instance to the ForeignKey
        room = get_object_or_404(Room, pk=room_id)
        new_task.room_no = room

        new_task.task_description = task_description

        # Assign the Housekeeper (foreign key)
        assigned_to = get_object_or_404(Housekeeper, pk=assigned_to_id)
        new_task.assigned_to = assigned_to

        new_task.due_date = due_date
        new_task.due_time = due_time

        # Save the new task to the database
        new_task.save()

        return redirect(reverse('tasklists'))  # Redirect to task list after saving

    return render(request, 'svassigntaskform.html')  # In case of GET, render the form again

def room_status_view(request):
    rooms = Room.objects.all()  # Get all room objects
    return render(request, 'svroomstatus.html', {'rooms': rooms})

def approve_status(request, room_no):
    room = get_object_or_404(Room, pk=room_no)  # Fetch the room object
    status_approve = request.POST.get('status_approve')  # Get the status from the form
    
    if status_approve == 'approve':
        room.room_status_approved = True  # Update the room approval status
    else:
        room.room_status_approved = False

    room.save()  # Save the changes to the database

    return redirect('room_status_view')  # Redirect back to the room status page
#i think u need to do the coding below like above
def lost_item_detail_view(request):
    lost_items = LostItem.objects.all()   # Fetch the lost item object
    return render(request, 'svlostitempg.html', {'lost_items': lost_items})  

def update_item_status(request, lost_item_id):
    item = get_object_or_404(LostItem, pk=lost_item_id)
    if request.method == 'POST':
        item_status = request.POST.get('item_status')
        item.item_status = item_status
        item.save()
        return redirect('lost_item_detail_view')  # Redirect to lost items list or other appropriate view
    return render(request, 'svlostitempg.html', {'item': item})

  #MANAGER PARTS

def manager_login(request):
    error = None
    if request.method == 'POST':
        mng_user_id = request.POST['user_id']
        mng_password = request.POST['password']

        mng_exists = Manager.objects.filter(user_id=mng_user_id, password=mng_password).exists()

        if mng_exists:
            request.session['user_id'] = mng_user_id  
            return redirect('manager_homepage')  
        else:
            error = "Invalid User ID or Password."
    
    return render(request, '4mngloginpg.html', {'error': error})

def manager_homepage(request):
    # Get the user ID from the session
    mng_user_id = request.session.get('user_id')

    if mng_user_id is None:
        return redirect('supervisor_login')  # Redirect to login if not authenticated


    manager = get_object_or_404(Manager, user_id=mng_user_id)

    if request.method == 'POST':
        form = ManagerProfileForm(request.POST, request.FILES, instance=manager)
        if form.is_valid():
            form.save()
            return redirect('manager_homepage')  
    else:
        form = ManagerProfileForm(instance=Manager)


    context = {
        'form': form,
        'manager': manager,
    }

    return render(request, 'mnghomepg.html', context)


def reportspage(request):
    return render(request, 'mngreportpg.html')

def room_task_report(request):
    rooms = Room.objects.all().select_related('cleaned_by')  # Get rooms with housekeeper info
    tasks = Task.objects.all().select_related('assigned_to', 'room_no')  # Get tasks with room and housekeeper info

    return render(request, 'mnghsreport.html', {'rooms': rooms, 'tasks': tasks})

def maintenance_list_view(request):
    # Retrieve only maintenance records with status 'Completed'
    maintenances = Maintenance.objects.filter(maintenance_status='approved')
    
    context = {
        'maintenances': maintenances,
    }
    return render(request, 'mngmaintncpg.html', context)


def approve_maintenance_view(request, maintenance_id):
    # Get the specific maintenance record
    maintenance = get_object_or_404(Maintenance, pk=maintenance_id)

    if request.method == 'POST':
        status = request.POST.get('status_approve')
        if status in ['approved', 'pending', 'rejected']:
            maintenance.maintenance_status = status
            maintenance.save()  # Save the updated status
            return redirect('maintenance_list_view')  # Redirect to the maintenance list

    return render(request, 'mngmaintncpg.html', {'maintenances': Maintenance.objects.all()})
def maintenance_report_view(request):
     # Retrieve only maintenance records with status 'Completed'
    maintenances = Maintenance.objects.filter(maintenance_status='approved')
    
    context = {
        'maintenances': maintenances,
    }
    return render(request,'mngmaintncrpt.html', context)

    
def supplies_report_view(request):
    approved_requests = SupplyRequest.objects.filter(status='approved')
    context = {
        'approved_requests': approved_requests
    }
    return render(request, 'mngsuppliesrpt.html', context)

def supply_request_list_view(request):
    supply_requests = SupplyRequest.objects.all()
    context = {
        'supply_requests': supply_requests,
    }
    return render(request, 'mngsuppliespg.html', context)

# View to approve/reject a supply request
# You may want to remove this decorator if you're using CSRF protection properly
def approve_supply_request(request, request_id):
    supply_request = get_object_or_404(SupplyRequest, id=request_id)
    
    if request.method == 'POST':
        new_status = request.POST.get('status_approve')
        if new_status:
            supply_request.status = new_status
            supply_request.save()
            return redirect('supply_request_list_view')  # Redirect to the list view after processing the request

    return redirect('supply_request_list_view')  # Default redirect if method is not POST
