from django.db import models
from django.utils import timezone


class Supervisor(models.Model):
    user_id = models.CharField(primary_key=True, max_length=100)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=15)
    picture = models.ImageField(upload_to='profile_pics/', default='default.jpg')

    def __str__(self):
        return self.name

class Housekeeper(models.Model):
    user_id = models.CharField(primary_key=True, max_length=100)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=15)
    picture = models.ImageField(upload_to='profile_pics/', default='default.jpg')

    def __str__(self):
        return self.name

class HousekeeperAvailability(models.Model):
    housekeeper = models.ForeignKey(Housekeeper, on_delete=models.CASCADE, related_name='availabilities')
    availability = models.BooleanField(default=True)
    reason = models.TextField(blank=True, null=True)
    date_assigned = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Availability for {self.housekeeper.name} on {self.date_assigned.strftime('%Y-%m-%d')}"

class Manager(models.Model):
    user_id = models.CharField(primary_key=True, max_length=100)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    contact_no = models.CharField(max_length=15)
    picture = models.ImageField(upload_to='profile_pics/', default='default.jpg')

    def __str__(self):
        return self.name

class Room(models.Model):
    room_no = models.CharField(primary_key=True, max_length=10)
    room_type = models.CharField(max_length=100)
    room_status = models.CharField(
        max_length=100, 
        choices=[('Clean', 'Clean'), ('Dirty', 'Dirty'), ('In Progress', 'In Progress')]
    )
    clean_date = models.DateTimeField(default=timezone.now)
    cleaned_by = models.ForeignKey(Housekeeper, on_delete=models.SET_NULL, null=True, blank=True)
    
    # New field to track room status approval
    room_status_approved = models.BooleanField(default=False)  # False by default, meaning not approved

    def __str__(self):
        return self.room_no


class Task(models.Model):
    task_id = models.AutoField(primary_key=True)
    room_no = models.ForeignKey(Room, on_delete=models.CASCADE)
    task_description = models.TextField()
    room_task_status = models.CharField(
        max_length=100, 
        choices=[('Pending', 'Pending'), ('Completed', 'Completed')]
    )
    assigned_to = models.ForeignKey(Housekeeper, on_delete=models.CASCADE, null=True, blank=True)
    due_date = models.DateField()
    due_time = models.TimeField()

    def __str__(self):
        return f"Task {self.task_id} for Room {self.room_no}"




class LostItem(models.Model):
    lost_item_id = models.AutoField(primary_key=True)
    room_no = models.ForeignKey(Room, on_delete=models.CASCADE)
    item_type = models.CharField(max_length=100)
    item_status = models.CharField(
        max_length=100, 
        choices=[('Returned', 'Returned'), ('Not Returened', 'Not Returened')]
    )
    created_by = models.ForeignKey(Housekeeper, on_delete=models.CASCADE, null=True, blank=True)
 # Tracks who created the item
    created_at = models.DateTimeField(auto_now_add=True)     # Automatically sets the date when created

    def __str__(self):
        return self.item_type




class Maintenance(models.Model):
    maintenance_id = models.AutoField(primary_key=True)
    room_no = models.ForeignKey(Room, on_delete=models.CASCADE)
    maintenance_type = models.CharField(max_length=100)
    maintenance_description = models.TextField()
    maintenance_status = models.CharField(
        max_length=100, 
        choices=[('Pending', 'Pending'), ('Completed', 'Completed')]
    )
    created_by = models.ForeignKey(Housekeeper, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)  # Automatically sets the date when created

    def __str__(self):   
        return f"Maintenance for Room {self.room_no}"


class SupplyInventory(models.Model):
    supply_id = models.AutoField(primary_key=True)
    supply_name = models.CharField(max_length=100)
    current_quantity = models.IntegerField()
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2)
    update_date = models.DateField(auto_now=True)  # Auto-updates on save()
    
    def __str__(self):
        # Returns a simple string representation of the SupplyInventory
        return f'{self.supply_name} - Current Quantity: {self.current_quantity}'

class SupplyRequest(models.Model):
    supply = models.ForeignKey(SupplyInventory, on_delete=models.CASCADE)  # The requested supply
    requested_quantity = models.IntegerField()  # Quantity requested by the user
    requested_by = models.ForeignKey(Housekeeper, on_delete=models.CASCADE)  # The user making the request
    request_date = models.DateField(auto_now_add=True)  # Automatically store the request date
    status = models.CharField(max_length=20, default='Pending')  # Status of the request ('Pending', 'Approved', 'Rejected')

    def __str__(self):
        # Returns a simple string representation of the SupplyRequest
        return f'{self.supply.supply_name} - {self.requested_quantity} requested by {self.requested_by} ({self.status})'


class HousekeepingReport(models.Model):
    report_id = models.AutoField(primary_key=True)
    report_date = models.DateField(auto_now_add=True)
    tasks_completed = models.ManyToManyField(Task)
    rooms_cleaned = models.ManyToManyField(Room)

    def __str__(self):
        return f"Report {self.report_id} on {self.report_date}"

class SuppliesReport(models.Model):
    supplies_report_id = models.AutoField(primary_key=True)
    supply_report_date = models.DateField(auto_now_add=True)
    supplies_added = models.ManyToManyField(SupplyInventory)

    def __str__(self):
        return f"Supplies Report {self.supplies_report_id} on {self.supply_report_date}"

class MaintenanceReport(models.Model):
    maintenance_report_id = models.AutoField(primary_key=True)
    maintenance_report_date = models.DateField(auto_now_add=True)
    maintenance_completed = models.ManyToManyField(Maintenance)

    def __str__(self):
        return f"Maintenance Report {self.maintenance_report_id} on {self.maintenance_report_date}"
