# forms.py
from django import forms
from .models import Housekeeper, Supervisor, Manager

class HousekeeperProfileForm(forms.ModelForm):
    class Meta:
        model = Housekeeper
        fields = ['picture']  # Include other fields if necessary

class SupervisorProfileForm(forms.ModelForm):
    class Meta:
        model = Supervisor
        fields = ['picture']  # Include other fields if necessary

class ManagerProfileForm(forms.ModelForm):
    class Meta:
        model = Manager
        fields = ['picture']  # Include other fields if necessary


