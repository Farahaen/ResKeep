from django.shortcuts import redirect

class HousekeeperAuthMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Check if the user is authenticated before each request
        if request.session.get('user_id') is None and not request.path.startswith('/housekeeper/login/'):
            return redirect('housekeeper_login')

        return self.get_response(request)
