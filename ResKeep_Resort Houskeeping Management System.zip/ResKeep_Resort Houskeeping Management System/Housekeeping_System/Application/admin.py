from django.contrib import admin
from .models import Supervisor, Housekeeper, Manager, Room, Task, LostItem, Maintenance, SupplyInventory, HousekeepingReport, SuppliesReport, MaintenanceReport, SupplyRequest, HousekeeperAvailability

# Register the models
admin.site.register(Supervisor)
admin.site.register(Housekeeper)
admin.site.register(HousekeeperAvailability)
admin.site.register(Manager)
admin.site.register(Room)
admin.site.register(Task)
admin.site.register(LostItem)
admin.site.register(Maintenance)
admin.site.register(SupplyInventory)
admin.site.register(SupplyRequest)
admin.site.register(HousekeepingReport)
admin.site.register(SuppliesReport)
admin.site.register(MaintenanceReport)
