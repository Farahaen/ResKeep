# your_app/templatetags/supply_extras.py

from django import template

register = template.Library()

@register.simple_tag
def supply_image(supply_name):
    image_map = {
        'Sponges': 'sponges.png',
        'Gloves': 'glove.png',
        'Trash Bags': 'trashbag.png',
        'Mops': 'mop.png',
        'Brooms': 'broom.png',
        'Air Fresheners': 'airfreshner.png',
        'Clean Solution': 'cleansolution.png',
        'Brushes': 'brush.png',
        'Microfiber Cloths': 'microcloth.png',
        'Buckets': 'bucket.png',
    }
    return f'images/{image_map.get(supply_name, "default.png")}'
